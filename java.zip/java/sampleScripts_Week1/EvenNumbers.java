package sampleScripts_Week1;


public class EvenNumbers {

	public static void main(String[] args) {
		System.out.println("Even number between 20 and 100 are : ");
		for (int i=20;i<=100;i++)
		{
			if(i%2==0)
				System.out.println(i);
		}
	}

}
