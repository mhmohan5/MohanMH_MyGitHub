package tests;

import org.junit.Test;

import wrappers.GenericWrappers;

public class CreateLeadAllFields extends GenericWrappers {

	@Test
	public void CreateLead() {
		
		
		invokeApp("chrome","http://leaftaps.com/opentaps");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName", "Cognizant");
		enterById("createLeadForm_firstName", "Mohan");
		enterById("createLeadForm_lastName", "MH");
		selectVisibileTextById("createLeadForm_dataSourceId", "Cold Call");
		selectVisibileTextById("createLeadForm_marketingCampaignId", "Automobile");		
		enterById("createLeadForm_firstNameLocal", "MohanLocal");
		enterById("createLeadForm_lastNameLocal", "MHLocal");
		enterById("createLeadForm_personalTitle", "Mr");
		enterById("createLeadForm_generalProfTitle", "MrTitle");
		
		
		
	
		
		clickByClassName("smallSubmit");
		
	}

}
